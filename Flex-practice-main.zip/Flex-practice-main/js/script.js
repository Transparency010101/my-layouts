console.log('Hello wolrd!');
// $ Функции для прикола
function comment() {
    console.log('Комментировать');
}
function like() {
    console.log('Лайк');
}
function subscripe() {
    console.log('Подписаться');
}
