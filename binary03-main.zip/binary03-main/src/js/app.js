"use strict";

import * as fileIsWebP from './modules/flsfunc.js';

import "./scripts/smallscript.js";

fileIsWebP.isWebp();