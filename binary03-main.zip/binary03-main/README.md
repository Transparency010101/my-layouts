# Info comments
### ! - hierarchy comments
### * - Explanatory comments
### ? - Perhaps a bug, a defect, an error, did not complete something
### : - code navigation


# Обьеснение моментов в коде

## Чем отличаются .class от class?
Покажу на примере в файле _about.scss
Если написано с точкой в начале, (.about__headlines) то
этот класс написан без блока классов, как about-cards(3 строка в _about.scss)