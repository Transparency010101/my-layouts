console.log('Hello world!');
function work() {
    console.log('WORK WITH US!');
}