"use strict";
import * as module from './modules/modules.js';
module.isWebp();

// $ import "./source/$1.js";
import "./scripts/base.js";

import "./scripts/dom.js";
