"use strict";
import * as module from './modules/modules.js';
module.isWebp();
module.setAltTextInImg();

// $ import "../source/$1.js";

import "./scripts/dom.js";
import "./scripts/gooleMap.js";