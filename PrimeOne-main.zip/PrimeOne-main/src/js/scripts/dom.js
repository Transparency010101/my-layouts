// * тут небольшие DOM/BOM скрипты

// * Смена языка (без функционала) {
let headerLangsItem = document.querySelectorAll(".header-menu__langs-item");

if (headerLangsItem.length > 0) {

    headerLangsItem.forEach(tag => {
        tag.addEventListener("click", function () {

            headerLangsItem.forEach(tag => {
                if (tag.classList.contains("_active")) {
                    tag.classList.remove("_active");
                }
            });

            tag.classList.add("_active");
        });
    });

}
// * Смена языка (без функционала) }

