"use strict";
import * as module from './modules/modules.js';
module.isWebp();
module.setAltTextInImg();

// $ import "./source/$1.js";

import "./source/menu-burger.js";
import  "./source/filter.js";
import "./scripts/dom.js";