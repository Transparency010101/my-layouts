function body_load() {
    alert("Подождите немного пока сайт загрузится");
}
function read_more() {
    console.log('Read more');
}
console.log('Hello world!');
