"use strict";
import * as fileIsWebP from './modules/flsfunc.js';
fileIsWebP.isWebp();

import "./scripts/smallScript.js";
import "./scripts/swiper.js";
